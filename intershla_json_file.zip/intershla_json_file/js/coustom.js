$('.content').on('click',function(){
    console.log("Inside click");

    // var url = "https://dev.deepthought.education/assets/uploads/files/others/project.json";
    // // var data = JSON.parse(url);
    // // console.log(data);

    // $.ajax({
    //     datatType:"json",
    //     type: 'GET',
    //     url: url,
    //     data:{},
    //     sucess: function(data, status, shr){
    //         $(data).each(function(key,val){
    //             console.log(key,val);
    //         })
    //     }
    // })

    $.getJSON('https://dev.deepthought.education/assets/uploads/files/others/project.json',function(key){
        
        var text = `Title:${key.title}<br>
                     Tid:${key.tid} <br>
                     Type:${key.type}  `

        $(".all_data").html(text);
    })
});